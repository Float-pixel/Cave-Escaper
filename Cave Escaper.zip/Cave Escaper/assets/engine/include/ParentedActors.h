#ifndef PARENTED_ACTORS_H
#define PARENTED_ACTORS_H

#include <gb/gb.h>

void PositionParentedActors();

#endif