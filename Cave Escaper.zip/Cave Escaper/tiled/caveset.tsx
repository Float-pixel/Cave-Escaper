<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="caveset" tilewidth="8" tileheight="8" tilecount="720" columns="30">
 <grid orientation="orthogonal" width="2" height="2"/>
 <image source="Complete tileset.png" width="240" height="192"/>
</tileset>
