Thanks for checking out my game!

This is a real, working gameboy game. You can throw this onto a flash cart and it will run on actual gameboy hardware.

I have included the ROM of my game and a free to use gameboy emulator called BGB in the GAME folder.
You can run "bgb.exe" and then just drag "Cave Escaper.gb" into the window it creates to start playing!

Arrow Keys are the D-PAD, Z and X act as A and B, Enter and Shift as Start and Select.



BRIEF EXPLANATION OF GAMEPLAY:

The games 16 levels are arranged in a 4x4 grid. You start on the first floor in the bottom left corner and snake your way through the grid to reach the exit on the top left corner of the grid. But be careful! You can fall between the floors if you miss a jump! 

I hope you enjoy!


